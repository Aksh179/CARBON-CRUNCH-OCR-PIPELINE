"""
run.py
------
Entry point for the Carbon Crunch AI-OCR pipeline.

Usage
-----
    python run.py --input <folder_or_image> [--output outputs/] [--engine auto]

Examples
--------
    python run.py --input data/receipts/
    python run.py --input data/receipts/ --engine tesseract
    python run.py --input single_receipt.jpg --output my_results/
"""

import argparse
import json
import sys
import os
from pathlib import Path

# ── make src importable when running from project root ───────────────────────
sys.path.insert(0, str(Path(__file__).parent))

from src.ocr_pipeline import ReceiptOCRPipeline
from src.financial_summary import generate_summary


def parse_args():
    parser = argparse.ArgumentParser(
        description="Carbon Crunch AI-OCR Receipt Processor"
    )
    parser.add_argument(
        "--input", required=True,
        help="Path to a single image file or a directory of receipt images"
    )
    parser.add_argument(
        "--output", default="outputs",
        help="Directory to write JSON results (default: outputs/)"
    )
    parser.add_argument(
        "--engine", default="auto",
        choices=["auto", "easyocr", "tesseract"],
        help="OCR engine to use (default: auto — prefers EasyOCR)"
    )
    return parser.parse_args()


def main():
    args = parse_args()
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n{'='*60}")
    print("  Carbon Crunch – AI-OCR Receipt Processor")
    print(f"{'='*60}")
    print(f"  Engine  : {args.engine}")
    print(f"  Input   : {args.input}")
    print(f"  Output  : {out_dir}")
    print(f"{'='*60}\n")

    # ── initialise pipeline ───────────────────────────────────────────────────
    try:
        pipeline = ReceiptOCRPipeline(ocr_engine=args.engine)
    except RuntimeError as e:
        print(f"[ERROR] Could not initialise OCR engine: {e}")
        sys.exit(1)

    # ── run ───────────────────────────────────────────────────────────────────
    input_path = Path(args.input)
    if input_path.is_dir():
        results = pipeline.process_directory(str(input_path))
    elif input_path.is_file():
        print(f"  Processing: {input_path.name}")
        results = [pipeline.process_image(str(input_path))]
    else:
        print(f"[ERROR] Input path not found: {args.input}")
        sys.exit(1)

    if not results:
        print("[WARN] No images found / processed.")
        sys.exit(0)

    # ── write per-receipt JSON ────────────────────────────────────────────────
    print(f"\n  Writing individual receipt JSONs …")
    for r in results:
        stem = Path(r.file).stem
        out_file = out_dir / f"{stem}.json"
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(r.to_dict(), f, indent=2, ensure_ascii=False)
        flag = "⚠ LOW CONF" if r.overall_confidence < 0.70 else "✓"
        print(f"    {flag}  {r.file}  (overall_conf={r.overall_confidence:.2f})")

    # ── financial summary ─────────────────────────────────────────────────────
    summary = generate_summary(results)
    summary_file = out_dir / "financial_summary.json"
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    # ── print summary to console ──────────────────────────────────────────────
    print(f"\n{'─'*60}")
    print("  FINANCIAL SUMMARY")
    print(f"{'─'*60}")
    print(f"  Transactions processed : {summary['num_transactions']}")
    print(f"  Totals successfully    : {summary['num_with_total']}")
    print(f"  Total spend            : {summary['total_spend']:.2f}")
    print(f"  Flagged (low conf)     : {len(summary['flagged_receipts'])}")
    if summary["spend_per_store"]:
        print("\n  Spend per store:")
        for store, amt in summary["spend_per_store"].items():
            print(f"    {store:<30s}  {amt:>10.2f}")
    print(f"{'─'*60}")
    print(f"\n  Results written to: {out_dir.resolve()}\n")


if __name__ == "__main__":
    main()
