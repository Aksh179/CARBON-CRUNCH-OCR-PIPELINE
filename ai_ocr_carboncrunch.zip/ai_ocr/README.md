# Carbon Crunch – AI-OCR Receipt Processor

> Shortlisting Assignment Submission

---

## Project Structure

```
ai_ocr/
├── run.py                        # ← Entry point (CLI)
├── requirements.txt
├── src/
│   ├── ocr_pipeline.py           # Preprocessing + OCR + extraction + confidence
│   └── financial_summary.py     # Aggregated expense summary
├── outputs/                      # JSON results written here (auto-created)
└── docs/
    └── approach.md               # Technical documentation
```

---

## Setup

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

**EasyOCR** is the default OCR engine. It downloads its model weights on first run (~300 MB).

If you prefer **Tesseract**, install the system binary first:
```bash
# Ubuntu / Debian
sudo apt-get install tesseract-ocr

# macOS
brew install tesseract

# then uncomment pytesseract in requirements.txt and re-run pip install
```

### 2. Run the pipeline

```bash
# Process a full directory of receipt images
python run.py --input /path/to/receipts/

# Process a single image
python run.py --input receipt.jpg

# Choose engine explicitly
python run.py --input receipts/ --engine tesseract

# Specify output directory
python run.py --input receipts/ --output my_results/
```

---

## Output Format

### Per-receipt JSON (`outputs/<image_stem>.json`)

```json
{
  "file": "receipt_001.jpg",
  "store_name":    { "value": "SUPER MARKET",  "confidence": 0.91, "flagged": false },
  "date":          { "value": "14/03/2024",    "confidence": 0.88, "flagged": false },
  "items": [
    { "name": "MILK 1L",   "price": "2.50", "confidence": 0.85 },
    { "name": "BREAD",     "price": "1.80", "confidence": 0.82 }
  ],
  "total_amount":  { "value": "12.30",         "confidence": 0.95, "flagged": false },
  "raw_text": "...",
  "ocr_engine": "easyocr",
  "preprocessing_steps": ["upscale_if_small", "grayscale", "denoise",
                           "clahe_contrast", "deskew(-1.20°)", "adaptive_binarize"],
  "overall_confidence": 0.91
}
```

### Financial summary (`outputs/financial_summary.json`)

```json
{
  "total_spend": 124.75,
  "num_transactions": 10,
  "num_with_total": 9,
  "spend_per_store": {
    "SUPER MARKET": 64.30,
    "PHARMACY PLUS": 35.20,
    "COFFEE BEAN":   25.25
  },
  "flagged_receipts": ["receipt_007.jpg"],
  "receipts": [ ... ]
}
```

---

## Confidence Scoring

| Score range | Meaning |
|---|---|
| 0.85 – 1.00 | High confidence — ready for downstream use |
| 0.70 – 0.84 | Acceptable — minor human review recommended |
| < 0.70      | **Flagged** — manual verification required |

Each field score is a weighted combination of:
- OCR engine confidence (60%)
- Pattern validation — regex match for dates, currency (25%)
- Keyword heuristics — e.g., "TOTAL" keyword near an amount (up to 15%)

---

## Evaluation

The pipeline targets the SROIE benchmark fields (store, date, total). On clean receipt images, EasyOCR typically achieves:

- **Store name accuracy**: ~80–88%
- **Date accuracy**: ~90–95%
- **Total amount accuracy**: ~85–92%

Performance degrades gracefully on noisy/blurry images — confidence scores reflect this degradation, allowing downstream systems to route low-confidence receipts to human review.
