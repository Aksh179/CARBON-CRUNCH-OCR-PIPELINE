"""
financial_summary.py
---------------------
Aggregates ReceiptResult objects into a financial expense summary.
"""

import re
from collections import defaultdict
from typing import Optional


CURRENCY_EXTRACT = re.compile(r"[\$€£₹¥]?\s*([\d,]+(?:\.\d{1,2})?)")


def _parse_amount(raw: str) -> Optional[float]:
    """Return float value from a raw price string, or None on failure."""
    if not raw or raw in ("NOT FOUND", "ERROR"):
        return None
    m = CURRENCY_EXTRACT.search(raw.replace(",", ""))
    if m:
        try:
            return float(m.group(1))
        except ValueError:
            pass
    return None


def generate_summary(results: list) -> dict:
    """
    Parameters
    ----------
    results : list[ReceiptResult]

    Returns
    -------
    dict with:
        total_spend          – sum of all parsed totals
        num_transactions     – count of receipts processed
        num_with_total       – receipts where total was successfully extracted
        spend_per_store      – dict {store_name: total_spend}
        receipts             – per-receipt breakdown
        flagged_receipts     – files where overall_confidence < 0.70
    """
    total_spend = 0.0
    num_with_total = 0
    spend_per_store: dict[str, float] = defaultdict(float)
    receipt_breakdown = []
    flagged = []

    for r in results:
        amount = _parse_amount(r.total_amount.value)
        store = r.store_name.value if r.store_name.value not in (
            "UNKNOWN", "ERROR") else "Unknown Store"

        if amount is not None:
            total_spend += amount
            num_with_total += 1
            spend_per_store[store] += amount

        receipt_breakdown.append({
            "file": r.file,
            "store": store,
            "date": r.date.value,
            "total": r.total_amount.value,
            "parsed_amount": amount,
            "num_items": len(r.items),
            "overall_confidence": r.overall_confidence,
        })

        if r.overall_confidence < 0.70:
            flagged.append(r.file)

    return {
        "total_spend": round(total_spend, 2),
        "num_transactions": len(results),
        "num_with_total": num_with_total,
        "spend_per_store": {k: round(v, 2)
                             for k, v in sorted(
                                 spend_per_store.items(),
                                 key=lambda x: -x[1])},
        "receipts": receipt_breakdown,
        "flagged_receipts": flagged,
    }
