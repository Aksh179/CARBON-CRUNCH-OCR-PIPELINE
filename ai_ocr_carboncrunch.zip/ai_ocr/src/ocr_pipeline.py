"""
ocr_pipeline.py
---------------
Core OCR pipeline: preprocessing → text detection → field extraction → confidence scoring.
Supports EasyOCR (primary) with Tesseract as fallback.
"""

import cv2
import numpy as np
import json
import re
import os
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field, asdict

# ── Optional imports ──────────────────────────────────────────────────────────
try:
    import easyocr
    EASYOCR_AVAILABLE = True
except ImportError:
    EASYOCR_AVAILABLE = False

try:
    import pytesseract
    from PIL import Image
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ConfidentField:
    value: str
    confidence: float
    flagged: bool = False          # True when confidence < LOW_CONF_THRESHOLD

    def to_dict(self):
        return {"value": self.value, "confidence": round(self.confidence, 4),
                "flagged": self.flagged}


@dataclass
class ReceiptItem:
    name: str
    price: str
    confidence: float

    def to_dict(self):
        return {"name": self.name, "price": self.price,
                "confidence": round(self.confidence, 4)}


@dataclass
class ReceiptResult:
    file: str
    store_name: ConfidentField
    date: ConfidentField
    items: list[ReceiptItem]
    total_amount: ConfidentField
    raw_text: str
    ocr_engine: str
    preprocessing_steps: list[str]
    overall_confidence: float = 0.0

    def to_dict(self):
        d = {
            "file": self.file,
            "store_name": self.store_name.to_dict(),
            "date": self.date.to_dict(),
            "items": [i.to_dict() for i in self.items],
            "total_amount": self.total_amount.to_dict(),
            "raw_text": self.raw_text,
            "ocr_engine": self.ocr_engine,
            "preprocessing_steps": self.preprocessing_steps,
            "overall_confidence": round(self.overall_confidence, 4),
        }
        return d


LOW_CONF_THRESHOLD = 0.70


# ─────────────────────────────────────────────────────────────────────────────
# 1. Image Preprocessing
# ─────────────────────────────────────────────────────────────────────────────

class ImagePreprocessor:
    """Applies a chain of classical CV operations to improve OCR quality."""

    def __init__(self, target_dpi: int = 300):
        self.target_dpi = target_dpi

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _deskew(img_gray: np.ndarray) -> tuple[np.ndarray, float]:
        """Detect skew via Hough lines and rotate to correct it."""
        edges = cv2.Canny(img_gray, 50, 150, apertureSize=3)
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=80,
                                 minLineLength=50, maxLineGap=10)
        if lines is None:
            return img_gray, 0.0

        angles = []
        for line in lines:
            x1, y1, x2, y2 = line[0]
            if x2 != x1:
                angles.append(np.degrees(np.arctan2(y2 - y1, x2 - x1)))

        if not angles:
            return img_gray, 0.0

        median_angle = np.median(angles)
        if abs(median_angle) < 0.5:          # negligible skew
            return img_gray, median_angle

        h, w = img_gray.shape
        M = cv2.getRotationMatrix2D((w / 2, h / 2), median_angle, 1.0)
        rotated = cv2.warpAffine(img_gray, M, (w, h),
                                  flags=cv2.INTER_CUBIC,
                                  borderMode=cv2.BORDER_REPLICATE)
        return rotated, median_angle

    @staticmethod
    def _remove_noise(img: np.ndarray) -> np.ndarray:
        return cv2.fastNlMeansDenoising(img, h=10, templateWindowSize=7,
                                         searchWindowSize=21)

    @staticmethod
    def _fix_contrast(img: np.ndarray) -> np.ndarray:
        """CLAHE for local contrast enhancement."""
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        return clahe.apply(img)

    @staticmethod
    def _binarize(img: np.ndarray) -> np.ndarray:
        """Adaptive threshold handles uneven illumination."""
        return cv2.adaptiveThreshold(
            img, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 31, 11
        )

    @staticmethod
    def _upscale_if_small(img: np.ndarray) -> np.ndarray:
        h, w = img.shape[:2]
        if max(h, w) < 1000:
            scale = 1000 / max(h, w)
            img = cv2.resize(img, None, fx=scale, fy=scale,
                             interpolation=cv2.INTER_CUBIC)
        return img

    # ── public API ────────────────────────────────────────────────────────────

    def preprocess(self, image_path: str) -> tuple[np.ndarray, list[str]]:
        """
        Returns (processed_image_bgr_or_gray, list_of_steps_applied).
        The returned image is grayscale (single channel) ready for OCR.
        """
        steps: list[str] = []

        img = cv2.imread(image_path)
        if img is None:
            raise ValueError(f"Cannot read image: {image_path}")

        # Upscale tiny images
        img = self._upscale_if_small(img)
        steps.append("upscale_if_small")

        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        steps.append("grayscale")

        # Denoise
        gray = self._remove_noise(gray)
        steps.append("denoise")

        # Contrast
        gray = self._fix_contrast(gray)
        steps.append("clahe_contrast")

        # Deskew
        gray, angle = self._deskew(gray)
        if abs(angle) > 0.5:
            steps.append(f"deskew({angle:.2f}°)")

        # Binarize
        binary = self._binarize(gray)
        steps.append("adaptive_binarize")

        return binary, steps


# ─────────────────────────────────────────────────────────────────────────────
# 2. OCR Engine wrapper
# ─────────────────────────────────────────────────────────────────────────────

class OCREngine:
    """Unified wrapper around EasyOCR / Tesseract."""

    def __init__(self, engine: str = "auto"):
        if engine == "auto":
            engine = "easyocr" if EASYOCR_AVAILABLE else "tesseract"
        self.engine = engine

        if engine == "easyocr":
            if not EASYOCR_AVAILABLE:
                raise RuntimeError("easyocr not installed")
            self._reader = easyocr.Reader(["en"], gpu=False, verbose=False)
        elif engine == "tesseract":
            if not TESSERACT_AVAILABLE:
                raise RuntimeError("pytesseract / Pillow not installed")
        else:
            raise ValueError(f"Unknown engine: {engine}")

    def run(self, img_gray: np.ndarray) -> list[dict]:
        """
        Returns list of dicts:
          {"text": str, "confidence": float (0–1), "bbox": list}
        """
        if self.engine == "easyocr":
            return self._run_easyocr(img_gray)
        return self._run_tesseract(img_gray)

    def _run_easyocr(self, img: np.ndarray) -> list[dict]:
        results = self._reader.readtext(img, detail=1, paragraph=False)
        out = []
        for (bbox, text, conf) in results:
            out.append({"text": text.strip(), "confidence": float(conf),
                        "bbox": bbox})
        return out

    def _run_tesseract(self, img: np.ndarray) -> list[dict]:
        pil_img = Image.fromarray(img)
        data = pytesseract.image_to_data(
            pil_img, output_type=pytesseract.Output.DICT,
            config="--psm 6"
        )
        out = []
        for i, text in enumerate(data["text"]):
            text = text.strip()
            if not text:
                continue
            conf_raw = data["conf"][i]
            conf = max(0.0, float(conf_raw)) / 100.0
            x, y, w, h = (data["left"][i], data["top"][i],
                           data["width"][i], data["height"][i])
            out.append({"text": text, "confidence": conf,
                        "bbox": [[x, y], [x+w, y], [x+w, y+h], [x, y+h]]})
        return out


# ─────────────────────────────────────────────────────────────────────────────
# 3. Field Extractor with confidence scoring
# ─────────────────────────────────────────────────────────────────────────────

# Regex patterns for validation
DATE_PATTERNS = [
    r"\b\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}\b",
    r"\b\d{4}[/\-\.]\d{1,2}[/\-\.]\d{1,2}\b",
    r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2},?\s+\d{4}\b",
    r"\b\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{4}\b",
]
CURRENCY_PATTERN = r"[$€£₹¥]?\s*\d{1,6}(?:[,\.]\d{2,3})*(?:[\.]\d{2})?"
TOTAL_KEYWORDS = {"total", "amount", "grand total", "sum", "balance", "due",
                   "subtotal", "net", "payable", "paid"}
NOISE_WORDS = {"the", "and", "a", "to", "of", "in", "for", "is", "at", "on"}


class FieldExtractor:

    def extract_all(self, ocr_words: list[dict]) -> dict:
        full_text = " ".join(w["text"] for w in ocr_words)
        lines = self._group_into_lines(ocr_words)

        store_name = self._extract_store_name(lines, ocr_words)
        date = self._extract_date(full_text, ocr_words)
        total = self._extract_total(lines, ocr_words)
        items = self._extract_items(lines)

        return {
            "store_name": store_name,
            "date": date,
            "total_amount": total,
            "items": items,
            "raw_text": full_text,
        }

    # ── grouping helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _get_y(word: dict) -> float:
        bbox = word["bbox"]
        if isinstance(bbox[0], (list, tuple)):
            return bbox[0][1]
        return bbox[1]

    def _group_into_lines(self, words: list[dict],
                           y_tolerance: int = 12) -> list[list[dict]]:
        if not words:
            return []
        sorted_words = sorted(words, key=lambda w: (self._get_y(w),))
        lines: list[list[dict]] = [[sorted_words[0]]]
        for w in sorted_words[1:]:
            if abs(self._get_y(w) - self._get_y(lines[-1][-1])) <= y_tolerance:
                lines[-1].append(w)
            else:
                lines.append([w])
        return lines

    # ── store name ────────────────────────────────────────────────────────────

    def _extract_store_name(self, lines: list[list[dict]],
                             all_words: list[dict]) -> ConfidentField:
        """Heuristic: first 1-3 lines, longest token cluster, exclude dates/prices."""
        candidates = []
        for line in lines[:4]:
            text = " ".join(w["text"] for w in line).strip()
            if not text or len(text) < 2:
                continue
            # Skip lines that are purely numeric or look like a date/price
            if re.fullmatch(r"[\d\s/\-\.\$€£₹,]+", text):
                continue
            avg_conf = np.mean([w["confidence"] for w in line])
            candidates.append((text, avg_conf, len(line)))

        if not candidates:
            return ConfidentField("UNKNOWN", 0.0, flagged=True)

        # prefer longest candidate in top 3 lines
        best = max(candidates[:3], key=lambda x: (len(x[0]), x[1]))
        conf = self._field_confidence(best[1], pattern_valid=True,
                                       keyword_bonus=0.0)
        return ConfidentField(best[0], conf,
                               flagged=conf < LOW_CONF_THRESHOLD)

    # ── date ──────────────────────────────────────────────────────────────────

    def _extract_date(self, full_text: str,
                       all_words: list[dict]) -> ConfidentField:
        for pat in DATE_PATTERNS:
            m = re.search(pat, full_text, re.IGNORECASE)
            if m:
                span_text = m.group(0)
                # find avg OCR conf for words overlapping the match
                word_confs = [w["confidence"] for w in all_words
                               if w["text"] in span_text]
                ocr_conf = float(np.mean(word_confs)) if word_confs else 0.75
                conf = self._field_confidence(ocr_conf, pattern_valid=True,
                                               keyword_bonus=0.05)
                return ConfidentField(span_text, conf,
                                       flagged=conf < LOW_CONF_THRESHOLD)

        return ConfidentField("NOT FOUND", 0.1, flagged=True)

    # ── total amount ──────────────────────────────────────────────────────────

    def _extract_total(self, lines: list[list[dict]],
                        all_words: list[dict]) -> ConfidentField:
        best_value = None
        best_conf = 0.0

        for line in lines:
            line_text = " ".join(w["text"] for w in line).lower()
            keyword_hit = any(kw in line_text for kw in TOTAL_KEYWORDS)

            # find currency amounts in this line
            amounts = re.findall(CURRENCY_PATTERN,
                                  " ".join(w["text"] for w in line))
            if not amounts:
                continue

            avg_conf = float(np.mean([w["confidence"] for w in line]))
            keyword_bonus = 0.15 if keyword_hit else 0.0
            conf = self._field_confidence(avg_conf, pattern_valid=True,
                                           keyword_bonus=keyword_bonus)

            # pick the line with a keyword + highest conf
            if conf > best_conf:
                best_conf = conf
                best_value = amounts[-1].strip()  # rightmost = total

        if best_value:
            return ConfidentField(best_value, best_conf,
                                   flagged=best_conf < LOW_CONF_THRESHOLD)
        return ConfidentField("NOT FOUND", 0.1, flagged=True)

    # ── line items ────────────────────────────────────────────────────────────

    def _extract_items(self, lines: list[list[dict]]) -> list[ReceiptItem]:
        items = []
        for line in lines:
            text_parts = [w["text"] for w in line]
            full = " ".join(text_parts)

            # A valid item line: has at least one word (name) + a price
            prices = re.findall(CURRENCY_PATTERN, full)
            if not prices:
                continue

            # Filter out lines that are just totals
            lower = full.lower()
            if any(kw in lower for kw in TOTAL_KEYWORDS):
                continue

            price = prices[-1].strip()
            # Name = everything before the last price occurrence
            name = full[: full.rfind(price)].strip()
            if not name or len(name) < 2:
                continue

            avg_conf = float(np.mean([w["confidence"] for w in line]))
            items.append(ReceiptItem(name=name, price=price,
                                      confidence=round(avg_conf, 4)))

        return items

    # ── confidence formula ────────────────────────────────────────────────────

    @staticmethod
    def _field_confidence(ocr_conf: float, pattern_valid: bool,
                           keyword_bonus: float) -> float:
        base = ocr_conf * 0.6
        pattern_score = 0.25 if pattern_valid else 0.0
        conf = base + pattern_score + keyword_bonus
        return min(1.0, conf)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Pipeline orchestrator
# ─────────────────────────────────────────────────────────────────────────────

class ReceiptOCRPipeline:

    def __init__(self, ocr_engine: str = "auto"):
        self.preprocessor = ImagePreprocessor()
        self.ocr = OCREngine(engine=ocr_engine)
        self.extractor = FieldExtractor()

    def process_image(self, image_path: str) -> ReceiptResult:
        fname = Path(image_path).name

        # 1. Preprocess
        try:
            processed, steps = self.preprocessor.preprocess(image_path)
        except Exception as e:
            return self._error_result(fname, str(e))

        # 2. OCR
        try:
            ocr_words = self.ocr.run(processed)
        except Exception as e:
            return self._error_result(fname, f"OCR error: {e}")

        if not ocr_words:
            return self._error_result(fname, "No text detected")

        # 3. Extract fields
        extracted = self.extractor.extract_all(ocr_words)

        # 4. Build result
        result = ReceiptResult(
            file=fname,
            store_name=extracted["store_name"],
            date=extracted["date"],
            items=extracted["items"],
            total_amount=extracted["total_amount"],
            raw_text=extracted["raw_text"],
            ocr_engine=self.ocr.engine,
            preprocessing_steps=steps,
        )

        # Overall confidence = weighted average of key fields
        result.overall_confidence = round(
            0.3 * result.store_name.confidence
            + 0.3 * result.total_amount.confidence
            + 0.2 * result.date.confidence
            + 0.2 * (np.mean([i.confidence for i in result.items])
                     if result.items else 0.5),
            4,
        )
        return result

    def process_directory(self, directory: str) -> list[ReceiptResult]:
        image_extensions = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif",
                             ".webp"}
        paths = [
            p for p in Path(directory).iterdir()
            if p.suffix.lower() in image_extensions
        ]
        results = []
        for p in sorted(paths):
            print(f"  Processing: {p.name}")
            results.append(self.process_image(str(p)))
        return results

    @staticmethod
    def _error_result(fname: str, msg: str) -> ReceiptResult:
        empty = ConfidentField("ERROR", 0.0, flagged=True)
        return ReceiptResult(
            file=fname,
            store_name=ConfidentField(f"ERROR: {msg}", 0.0, flagged=True),
            date=empty, items=[], total_amount=empty,
            raw_text="", ocr_engine="none", preprocessing_steps=[],
            overall_confidence=0.0,
        )
